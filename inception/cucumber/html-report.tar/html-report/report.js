$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/concombre/DuplicateTags.feature");
formatter.feature({
  "name": "Stock Management To Check Duplicate Execution",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@Everything"
    },
    {
      "name": "@Feature"
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I\u0027ve 2 products",
  "keyword": "Given "
});
formatter.match({
  "location": "AnnotationSteps.i_ve_number_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add 3 additional products",
  "keyword": "And "
});
formatter.match({
  "location": "AnnotationSteps.i_had_number_additional_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Current stock duplicate",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@Everything"
    },
    {
      "name": "@Feature"
    },
    {
      "name": "@Everything"
    },
    {
      "name": "@Scenario"
    },
    {
      "name": "@FeatureChild"
    },
    {
      "name": "@FirstScenario"
    }
  ]
});
formatter.step({
  "name": "I count everything I have in stock",
  "keyword": "When "
});
formatter.match({
  "location": "AnnotationSteps.i_count_everything_i_have_in_stock()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I\u0027ve at least 5 products in stock",
  "keyword": "Then "
});
formatter.match({
  "location": "AnnotationSteps.i_ve_at_least_number_products_in_stock(int)"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I\u0027ve 2 products",
  "keyword": "Given "
});
formatter.match({
  "location": "AnnotationSteps.i_ve_number_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add 3 additional products",
  "keyword": "And "
});
formatter.match({
  "location": "AnnotationSteps.i_had_number_additional_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Error in stock duplicate",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@Everything"
    },
    {
      "name": "@Feature"
    },
    {
      "name": "@Everything"
    },
    {
      "name": "@Scenario"
    },
    {
      "name": "@FeatureChild"
    },
    {
      "name": "@SecondScenario"
    }
  ]
});
formatter.step({
  "name": "I count everything I have in stock",
  "keyword": "When "
});
formatter.match({
  "location": "AnnotationSteps.i_count_everything_i_have_in_stock()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I\u0027ve at least 9 products in stock",
  "keyword": "Then "
});
formatter.match({
  "location": "AnnotationSteps.i_ve_at_least_number_products_in_stock(int)"
});
formatter.result({
  "error_message": "java.lang.AssertionError: There is not enough stock\n\tat org.junit.Assert.fail(Assert.java:88)\n\tat org.junit.Assert.assertTrue(Assert.java:41)\n\tat concombre.AnnotationSteps.i_ve_at_least_number_products_in_stock(AnnotationSteps.java:37)\n\tat ✽.I\u0027ve at least 9 products in stock(file:src/test/resources/concombre/DuplicateTags.feature:16)\n",
  "status": "failed"
});
formatter.scenarioOutline({
  "name": "New products duplicate",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@Everything"
    },
    {
      "name": "@ScenarioOutline"
    },
    {
      "name": "@FeatureChild"
    }
  ]
});
formatter.step({
  "name": "I need to add some \u003cproduct\u003e",
  "keyword": "Given "
});
formatter.step({
  "name": "I know how much I have",
  "keyword": "And "
});
formatter.step({
  "name": "I add it to the stock",
  "keyword": "When "
});
formatter.step({
  "name": "I should have more than the minimum needed",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "product"
      ]
    },
    {
      "cells": [
        "\"Ladder\""
      ]
    },
    {
      "cells": [
        "\"Chest\""
      ]
    },
    {
      "cells": [
        "\"Table\""
      ]
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I\u0027ve 2 products",
  "keyword": "Given "
});
formatter.match({
  "location": "AnnotationSteps.i_ve_number_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add 3 additional products",
  "keyword": "And "
});
formatter.match({
  "location": "AnnotationSteps.i_had_number_additional_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "New products duplicate",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@Everything"
    },
    {
      "name": "@Feature"
    },
    {
      "name": "@Everything"
    },
    {
      "name": "@ScenarioOutline"
    },
    {
      "name": "@FeatureChild"
    }
  ]
});
formatter.step({
  "name": "I need to add some \"Ladder\"",
  "keyword": "Given "
});
formatter.match({
  "location": "AnnotationSteps.i_need_to_add_some_product(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I know how much I have",
  "keyword": "And "
});
formatter.match({
  "location": "AnnotationSteps.i_knom_how_much_i_have()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add it to the stock",
  "keyword": "When "
});
formatter.match({
  "location": "AnnotationSteps.i_add_it_to_the_stock()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should have more than the minimum needed",
  "keyword": "Then "
});
formatter.match({
  "location": "AnnotationSteps.i_should_have_more_than_the_minimum_needed()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I\u0027ve 2 products",
  "keyword": "Given "
});
formatter.match({
  "location": "AnnotationSteps.i_ve_number_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add 3 additional products",
  "keyword": "And "
});
formatter.match({
  "location": "AnnotationSteps.i_had_number_additional_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "New products duplicate",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@Everything"
    },
    {
      "name": "@Feature"
    },
    {
      "name": "@Everything"
    },
    {
      "name": "@ScenarioOutline"
    },
    {
      "name": "@FeatureChild"
    }
  ]
});
formatter.step({
  "name": "I need to add some \"Chest\"",
  "keyword": "Given "
});
formatter.match({
  "location": "AnnotationSteps.i_need_to_add_some_product(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I know how much I have",
  "keyword": "And "
});
formatter.match({
  "location": "AnnotationSteps.i_knom_how_much_i_have()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add it to the stock",
  "keyword": "When "
});
formatter.match({
  "location": "AnnotationSteps.i_add_it_to_the_stock()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should have more than the minimum needed",
  "keyword": "Then "
});
formatter.match({
  "location": "AnnotationSteps.i_should_have_more_than_the_minimum_needed()"
});
formatter.result({
  "status": "passed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I\u0027ve 2 products",
  "keyword": "Given "
});
formatter.match({
  "location": "AnnotationSteps.i_ve_number_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add 3 additional products",
  "keyword": "And "
});
formatter.match({
  "location": "AnnotationSteps.i_had_number_additional_products(int)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "New products duplicate",
  "description": "",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "name": "@Everything"
    },
    {
      "name": "@Feature"
    },
    {
      "name": "@Everything"
    },
    {
      "name": "@ScenarioOutline"
    },
    {
      "name": "@FeatureChild"
    }
  ]
});
formatter.step({
  "name": "I need to add some \"Table\"",
  "keyword": "Given "
});
formatter.match({
  "location": "AnnotationSteps.i_need_to_add_some_product(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I know how much I have",
  "keyword": "And "
});
formatter.match({
  "location": "AnnotationSteps.i_knom_how_much_i_have()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add it to the stock",
  "keyword": "When "
});
formatter.match({
  "location": "AnnotationSteps.i_add_it_to_the_stock()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should have more than the minimum needed",
  "keyword": "Then "
});
formatter.match({
  "location": "AnnotationSteps.i_should_have_more_than_the_minimum_needed()"
});
formatter.result({
  "error_message": "java.lang.AssertionError: Error detected, we need at least 5 products, right now we have only 3 products\n\tat org.junit.Assert.fail(Assert.java:88)\n\tat org.junit.Assert.assertTrue(Assert.java:41)\n\tat concombre.AnnotationSteps.i_should_have_more_than_the_minimum_needed(AnnotationSteps.java:70)\n\tat ✽.I should have more than the minimum needed(file:src/test/resources/concombre/DuplicateTags.feature:23)\n",
  "status": "failed"
});
});